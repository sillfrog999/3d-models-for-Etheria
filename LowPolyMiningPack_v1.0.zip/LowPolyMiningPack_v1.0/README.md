# Low Poly Mining Pack (Free)
by reodesuxz

29 free low poly mining and cave assets

## Contents
- FBX/  - one .fbx per model (Unity, Unreal, Godot, Blender)
- GLB/  - one .glb per model (Godot, three.js, Babylon.js, web)
- OBJ/  - one .obj + .mtl per model
- Mining_AllAssets.blend - every model in one Blender file (Blender 4.3+)

## Specs
- Total: 1912 triangles for all 29 models (20-196 tris each)
- Flat-shaded, simple shared materials (no textures needed)
- Real-world scale in metres, pivot at the base centre

| Model | Category | Tris | Size (cm) |
|---|---|---|---|
| crystal_cluster | Rocks | 68 | 51 x 41 x 70 |
| crystal_pink | Rocks | 52 | 44 x 37 x 60 |
| boulder | Rocks | 20 | 122 x 110 x 97 |
| rock_small | Rocks | 20 | 53 x 44 x 32 |
| stalagmite | Rocks | 24 | 58 x 57 x 120 |
| stalactite | Rocks | 24 | 58 x 57 x 120 |
| gold_ore | Rocks | 80 | 77 x 66 x 48 |
| coal_pile | Rocks | 180 | 59 x 54 x 30 |
| ore_vein_wall | Rocks | 72 | 160 x 51 x 160 |
| gem_pile | Rocks | 100 | 37 x 32 x 14 |
| minecart | Rail | 196 | 90 x 120 x 90 |
| rail_straight | Rail | 84 | 110 x 200 x 13 |
| rail_buffer | Rail | 72 | 110 x 116 x 45 |
| rail_switch_lever | Rail | 52 | 30 x 30 x 82 |
| pickaxe | Tools | 56 | 94 x 75 x 8 |
| shovel | Tools | 32 | 20 x 4 x 108 |
| sledgehammer | Tools | 32 | 28 x 12 x 88 |
| dynamite | Tools | 68 | 16 x 25 x 15 |
| tnt_crate | Tools | 36 | 60 x 54 x 40 |
| mining_helmet | Tools | 68 | 36 x 36 x 21 |
| oil_lantern | Tools | 96 | 20 x 20 x 28 |
| support_beam | Structures | 36 | 240 x 22 x 220 |
| support_beam_cross | Structures | 48 | 240 x 22 x 220 |
| mine_entrance | Structures | 72 | 360 x 65 x 267 |
| wooden_ladder | Structures | 96 | 56 x 6 x 200 |
| ore_bucket | Structures | 60 | 50 x 50 x 75 |
| wooden_barrel | Structures | 84 | 62 x 62 x 70 |
| wall_torch | Props | 40 | 12 x 26 x 67 |
| warning_sign | Props | 44 | 50 x 4 x 120 |

## License
See LICENSE.txt. Free to use in unlimited personal and commercial projects. You may not resell or redistribute the models themselves.
If this pack helped you, a small tip on itch.io keeps more free packs coming. Thank you!
