Winter Wonderland
A free 3D model kit from Shuriken Studio
https://shuriken.studio/kits/winter-wonderland

A free low-poly winter wonderland kit for Roblox Studio: 25 matching GLB models of snow and ice for a winter adventure, a survival game or a frozen world. Landmarks include a frozen waterfall, an ice cave entrance, an ice bridge, a frozen ice tower, an ice throne, frozen ruins and a snowy mountain peak for the edge of the map. Build the ground with a frozen lake, a winter stream crossing, a sledding hill, a viewpoint platform, snowy cliff pieces that fit together, snow drifts and icicles. Snowy pines, frosted shrubs and glowing ice crystals fill the gaps, with a winter campsite and a frozen tree arch to give players somewhere to go. Wildlife brings it to life: a wolf, a polar bear, a moose, an arctic fox and snowy owl, and a seal and walrus. Ice sculptures add a festive touch. All of it is sized in studs and shares the library's stylised look.

25 models, as GLB (glTF 2.0) files:
  frozen-ice-tower.glb          Frozen Ice Tower  https://shuriken.studio/models/buildings/frozen-ice-tower
  frozen-cliff-waterfall.glb    Frozen Cliff Waterfall  https://shuriken.studio/models/scenery/frozen-cliff-waterfall
  low-poly-polar-bear.glb       Low-poly Polar Bear  https://shuriken.studio/models/characters/low-poly-polar-bear
  low-poly-winter-wolf.glb      Low-poly Winter Wolf  https://shuriken.studio/models/characters/low-poly-winter-wolf
  low-poly-winter-moose.glb     Low-Poly Winter Moose  https://shuriken.studio/models/characters/low-poly-winter-moose
  ice-sculpture-set.glb         Ice Sculpture Set  https://shuriken.studio/models/props/ice-sculpture-set
  low-poly-snow-drift-set.glb   Low-Poly Snow Drift Set  https://shuriken.studio/models/nature/low-poly-snow-drift-set
  seal-and-walrus-floes.glb     Seal and Walrus Floes  https://shuriken.studio/models/characters/seal-and-walrus-floes
  winter-ridge-viewpoint.glb    Winter Ridge Viewpoint  https://shuriken.studio/models/scenery/winter-ridge-viewpoint
  low-poly-ice-bridge.glb       Low-Poly Ice Bridge  https://shuriken.studio/models/scenery/low-poly-ice-bridge
  snowy-mountain-peak.glb       Snowy Mountain Peak  https://shuriken.studio/models/scenery/snowy-mountain-peak
  snowy-sledding-hill.glb       Snowy Sledding Hill  https://shuriken.studio/models/scenery/snowy-sledding-hill
  ice-cave-entrance.glb         Ice Cave Entrance  https://shuriken.studio/models/scenery/ice-cave-entrance
  frozen-winter-lake.glb        Frozen Winter Lake  https://shuriken.studio/models/scenery/frozen-winter-lake
  frozen-tree-arch.glb          Frozen Tree Arch  https://shuriken.studio/models/scenery/frozen-tree-arch
  frozen-stone-ruins.glb        Frozen Stone Ruins  https://shuriken.studio/models/scenery/frozen-stone-ruins
  snowy-cliff-kit.glb           Snowy Cliff Kit  https://shuriken.studio/models/kits/snowy-cliff-kit
  winter-stream-crossing.glb    Winter Stream Crossing  https://shuriken.studio/models/scenery/winter-stream-crossing
  low-poly-icicle-set.glb       Low-poly Icicle Set  https://shuriken.studio/models/nature/low-poly-icicle-set
  arctic-fox-and-snowy-owl.glb  Arctic Fox & Snowy Owl  https://shuriken.studio/models/characters/arctic-fox-and-snowy-owl
  frosted-shrub-set.glb         Frosted Shrub Set  https://shuriken.studio/models/nature/frosted-shrub-set
  winter-campsite.glb           Winter Campsite  https://shuriken.studio/models/scenery/winter-campsite
  snowy-pine-tree-set.glb       Snowy Pine Tree Set  https://shuriken.studio/models/nature/snowy-pine-tree-set
  low-poly-ice-throne.glb       Low-Poly Ice Throne  https://shuriken.studio/models/furniture/low-poly-ice-throne
  ice-crystal-set.glb           Ice Crystal Set  https://shuriken.studio/models/nature/ice-crystal-set

Using them
  Roblox Studio: Import 3D, choose a GLB, insert.
  Blender: File > Import > glTF 2.0.
  Unity, Godot, Unreal, three.js: import directly or through glTF.

Terms
  Free to use in any project, commercial games included: no account, no fee and no credit needed.
  Don't sell or share the model files themselves, alone or as a pack. They come as they are, with
  no warranty. LICENSE.txt has the short version; the full license is at https://shuriken.studio/legal/models
