# Enchanted Wilds Free Forest v1.0.0

All twelve forest props are free. Use them in commercial or non-commercial games under LICENSE.txt; credit is optional. Standalone asset resale/redistribution is prohibited. This is not a CC0 pack.

## Choose a download

- Models: twelve self-contained textured GLBs. Import into your engine or Blender. GLB uses meters and Y-up; each prop is centered horizontally with its base at ground level.
- Godot Quickstart: the twelve props plus an editable clearing and the already-free Leafy Sprout Blob with nine animations. Tested in Godot 4.6.3. Open project.godot, wait for import, then press F5. Open forest-layout.tscn to edit the environment placements in the scene editor. forest.gd contains demo controls and lighting/layout generation; the saved environment is reused at runtime.
- Blender Sources: twelve editable .blend files with their optimized textures packed, plus individual previews. Verified in Blender 4.5.13 LTS. The original 8K downloads are not included in these lightweight source files.

## Controls

WASD moves Leafy within the central clearing. Space casts the three-stalk special, R resets, right-drag orbits, the mouse wheel zooms and Tab toggles controls. Buttons select actions, camera views and reset. The movement is a bounded presentation controller, not a complete game or combat/navigation system. Simple collision is provided for the ground and larger props; small foliage is decorative.

## Textures and geometry

The complete twelve-model set contains 75,092 triangles. Individual props range from 4,329 to 8,145 triangles. Both trees have up to 2K color, 1K normal and 512px metallic/roughness maps. Other props have up to 1K color, 512px normal and 256px metallic/roughness maps. Color maps use JPEG; normal and material data use PNG. Geometry, UVs and vertex-normal bytes were preserved. File-size reduction is distinct from measured GPU memory and performance.

Keep models/leafy-sprout-blob/model.glb.import in the Godot project. Its tested settings disable automatic geometry compression and LOD/shadow-mesh generation for the animated effect mesh and retain authored 24fps animation import. Removing those overrides can deform the beanstalk effects on a fresh import. Static props use the normal Godot import pipeline. Other engines and Godot versions have not been verified.

## Matching creatures

Leafy is free: https://ritzman99.itch.io/enchanted-wilds-fantasy-monsters#demo
Optional paid monster pack: https://ritzman99.itch.io/enchanted-wilds-fantasy-monsters#purchase
The paid pack costs $4.99 and contains eight creatures including Leafy, 99 animation clips and editable Blender sources. It is a separate purchase. No paid purchase is needed to use any of these twelve forest props or the included Leafy demo.

Original models were created with the owner's paid Meshy account. AI-assisted tools helped with image/model creation, optimization, code, documentation and packaging, followed by human review. See LICENSE.txt for full usage terms. Support: comments on the itch.io pack page.
