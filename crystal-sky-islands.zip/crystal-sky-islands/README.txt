Crystal Sky Islands
A free 3D model kit from Shuriken Studio
https://shuriken.studio/kits/crystal-sky-islands

A free low-poly crystal sky islands kit for Roblox Studio: a matching set of glowing magic islands in several sizes for a fantasy sky world, a mining game or a magic quest. The hero island, about 100 studs across, carries a pale stone palace with crystal spires, giant purple and blue crystal clusters and a glowing pool beside a grand staircase. Two medium islands hold a crystal cave with a mine cart on a short track and a ring of rune stones around a crystal altar, a smaller island holds a garden of crystal flowers around a fountain, and three violet rock islets topped with crystals are sized for jumping between. Every island has a walkable top at player scale and dark rock underneath lit by glowing crystal veins. The set shares one look, and each piece is a detailed showpiece free for your games.

5 models, as GLB (glTF 2.0) files:
  crystal-palace-island.glb   Crystal Palace Island  https://shuriken.studio/models/scenery/crystal-palace-island
  crystal-cave-island.glb     Crystal Cave Island  https://shuriken.studio/models/scenery/crystal-cave-island
  rune-circle-sky-island.glb  Rune Circle Sky Island  https://shuriken.studio/models/scenery/rune-circle-sky-island
  crystal-garden-island.glb   Crystal Garden Island  https://shuriken.studio/models/scenery/crystal-garden-island
  crystal-sky-islets.glb      Crystal Sky Islets  https://shuriken.studio/models/scenery/crystal-sky-islets

Using them
  Roblox Studio: Import 3D, choose a GLB, insert.
  Blender: File > Import > glTF 2.0.
  Unity, Godot, Unreal, three.js: import directly or through glTF.

Terms
  Free to use in any project, commercial games included: no account, no fee and no credit needed.
  Don't sell or share the model files themselves, alone or as a pack. They come as they are, with
  no warranty. LICENSE.txt has the short version; the full license is at https://shuriken.studio/legal/models
